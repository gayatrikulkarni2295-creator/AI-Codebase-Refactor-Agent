import os
from pathlib import Path
from typing import List, Dict, Any

import google.generativeai as genai

from .code_utils import load_text_file


ANALYSIS_SYSTEM_PROMPT = """You are an expert software architect and code reviewer.

You will receive:
- A high-level description of a codebase (file list + some file contents).
Your tasks:
1. Identify code smells, risks, and maintainability issues.
2. Propose a refactor plan with clear steps.
3. Suggest improvements in:
   - structure & modularity
   - naming & readability
   - performance (if relevant)
   - documentation & comments
   - tests
4. Be concise but specific. Use bullet points and headings.
"""


REFACTOR_SYSTEM_PROMPT = """You are an expert software engineer.

You will be given the full *contents of a single file* from a codebase.
Your task:
- Return an improved, refactored version of the SAME file.
- Preserve the original public API and behavior unless something is obviously wrong.
- Improve:
  - structure (smaller functions, clearer logic)
  - naming and comments
  - docstrings
  - type hints (when appropriate)
- Do NOT add explanations or markdown.
- Output ONLY the new source code for this file.
"""


def _configure_gemini(api_key: str):
    """Configure the Gemini client with the given API key."""
    genai.configure(api_key=api_key)


def _get_model(model_name: str):
    return genai.GenerativeModel(model_name)


def analyze_codebase(
    root_dir: Path,
    code_files: List[Path],
    api_key: str,
    model_name: str = "gemini-1.5-flash",
    temperature: float = 0.2,
) -> str:
    """Create a high-level analysis of the codebase.

    We create a compact description by listing file paths and including
    truncated contents of the first few files to give the model context.
    """
    _configure_gemini(api_key)
    model = _get_model(model_name)

    file_summaries = []
    for path in code_files:
        rel = path.relative_to(root_dir)
        content = load_text_file(path)
        # Truncate content to avoid context blow-up.
        snippet = content[:4000]
        file_summaries.append(
            f"FILE: {rel}\nCONTENT SNIPPET (truncated):\n{snippet}\n---\n"
        )

    prompt_parts = [
        ANALYSIS_SYSTEM_PROMPT,
        "Below is a description of the codebase files and snippets:",
        "\n".join(file_summaries),
        "Now produce your detailed refactor and quality report.",
    ]

    response = model.generate_content(
        prompt_parts,
        generation_config={
            "temperature": temperature,
        },
    )
    return response.text or "(No response text from model.)"


def refactor_file_with_gemini(
    path: Path,
    root_dir: Path,
    api_key: str,
    model_name: str = "gemini-1.5-flash",
    temperature: float = 0.2,
) -> str:
    """Refactor a single file using Gemini and return the new contents.

    If something goes wrong, raise the exception to the caller.
    """
    _configure_gemini(api_key)
    model = _get_model(model_name)

    original_code = load_text_file(path)
    rel = path.relative_to(root_dir)

    user_prompt = (
        f"Here is the full content of the file `{rel}` from a codebase. "
        "Refactor it according to the system instructions.\n\n"
        f"{original_code}"
    )

    response = model.generate_content(
        [
            REFACTOR_SYSTEM_PROMPT,
            user_prompt,
        ],
        generation_config={
            "temperature": temperature,
        },
    )

    if not response.text:
        raise RuntimeError("Gemini returned an empty response while refactoring file.")

    return response.text


def refactor_codebase(
    root_dir: Path,
    code_files: List[Path],
    api_key: str,
    model_name: str = "gemini-1.5-flash",
    temperature: float = 0.2,
) -> List[Dict[str, Any]]:
    """Refactor multiple files in the codebase.

    Returns a list of dicts, one per file:
    {
        "path": Path,
        "old_content": str,
        "new_content": Optional[str],  # None if unchanged or error
        "error": Optional[str],
    }
    """
    results: List[Dict[str, Any]] = []

    for path in code_files:
        original_code = load_text_file(path)
        result: Dict[str, Any] = {
            "path": path,
            "old_content": original_code,
            "new_content": None,
            "error": None,
        }

        try:
            new_code = refactor_file_with_gemini(
                path=path,
                root_dir=root_dir,
                api_key=api_key,
                model_name=model_name,
                temperature=temperature,
            )
            result["new_content"] = new_code
        except Exception as exc:  # noqa: BLE001
            result["error"] = str(exc)

        results.append(result)

    return results
