"""Core package for the AI Codebase Refactor Agent."""
