from pathlib import Path
from typing import List

import difflib

SUPPORTED_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".java",
    ".cs",
    ".cpp",
    ".c",
}


def list_code_files(root_dir: Path) -> List[Path]:
    """Return a list of source code files under the given directory.

    Simple recursive search for files with SUPPORTED_EXTENSIONS.
    """
    files: List[Path] = []
    for path in root_dir.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix in SUPPORTED_EXTENSIONS:
            files.append(path)
    return sorted(files)


def load_text_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        # Fallback for weird encodings
        return path.read_text(errors="ignore")


def generate_diff(old_text: str, new_text: str, filename: str) -> str:
    """Return a unified diff as a single string for display in the UI."""
    old_lines = old_text.splitlines(keepends=False)
    new_lines = new_text.splitlines(keepends=False)
    diff_lines = difflib.unified_diff(
        old_lines,
        new_lines,
        fromfile=f"{filename} (original)",
        tofile=f"{filename} (refactored)",
        lineterm="",
    )
    return "\n".join(diff_lines)
