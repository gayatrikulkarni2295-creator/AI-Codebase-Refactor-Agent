import os
import tempfile
import zipfile
from pathlib import Path
from typing import List

import streamlit as st

from refactor_agent.agent import (
    analyze_codebase,
    refactor_codebase,
)
from refactor_agent.code_utils import (
    list_code_files,
    load_text_file,
    generate_diff,
)


st.set_page_config(
    page_title="AI Codebase Refactor Agent",
    page_icon="🧠",
    layout="wide",
)


def save_uploaded_zip(uploaded_file) -> Path:
    temp_dir = Path(tempfile.mkdtemp())
    zip_path = temp_dir / uploaded_file.name
    with open(zip_path, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return zip_path


def unzip_to_temp(zip_path: Path) -> Path:
    extract_dir = zip_path.parent / "extracted"
    extract_dir.mkdir(exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_dir)
    return extract_dir


def make_zip_from_dir(src_dir: Path) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zip_out:
        for file_path in src_dir.rglob("*"):
            if file_path.is_file():
                arcname = file_path.relative_to(src_dir)
                zip_out.write(file_path, arcname=str(arcname))
    buffer.seek(0)
    return buffer.read()


def main():
    st.title("🧠 AI Codebase Refactor Agent")
    st.markdown(
        """Refactor, document, and improve your codebase automatically using **Gemini** and simple Python tools.

        1. Enter your **Gemini API key**.
        2. Upload a **.zip file** containing your codebase.
        3. Choose **Analyze** or **Refactor** mode.
        """
    )

    with st.sidebar:
        st.header("⚙️ Settings")
        api_key = st.text_input(
            "Gemini API Key",
            type="password",
            help="Your Google Generative AI (Gemini) API key.",
        )
        model_name = st.text_input(
            "Model name",
            value="gemini-1.5-flash",
            help="You can change this if you have access to other Gemini models.",
        )
        temperature = st.slider("Temperature", 0.0, 1.0, 0.2, 0.05)
        max_files = st.slider(
            "Max files to process",
            1,
            50,
            10,
            help="Limit how many files are sent to the model to avoid token overuse.",
        )
        mode = st.radio(
            "Mode",
            ["Analyze only", "Refactor & show diff"],
            help="In 'Analyze only' the agent just produces a high-level report. In 'Refactor' it rewrites files.",
        )

    uploaded_zip = st.file_uploader(
        "Upload your codebase as a .zip file",
        type=["zip"],
    )

    if uploaded_zip is None:
        st.info("⬆️ Upload a .zip file to get started.")
        return

    if not api_key:
        st.warning("Please enter your Gemini API key in the sidebar to continue.")
        return

    zip_path = save_uploaded_zip(uploaded_zip)
    extracted_dir = unzip_to_temp(zip_path)

    st.success(f"Codebase extracted to: `{extracted_dir}`")

    code_files: List[Path] = list_code_files(extracted_dir)
    if not code_files:
        st.error("No supported code files found in the uploaded zip.")
        return

    st.subheader("📄 Detected code files")
    for file in code_files[:50]:
        st.write(f"- `{file.relative_to(extracted_dir)}`")
    if len(code_files) > 50:
        st.write(f"... and {len(code_files) - 50} more")

    if mode == "Analyze only":
        if st.button("🔍 Analyze codebase"):
            with st.spinner("Analyzing codebase with Gemini..."):
                report = analyze_codebase(
                    root_dir=extracted_dir,
                    code_files=code_files[:max_files],
                    api_key=api_key,
                    model_name=model_name,
                    temperature=temperature,
                )
            st.subheader("📊 Refactor Plan & Quality Report")
            st.markdown(report)
    else:
        if st.button("🛠️ Refactor and show diffs"):
            with st.spinner("Refactoring codebase with Gemini..."):
                refactor_results = refactor_codebase(
                    root_dir=extracted_dir,
                    code_files=code_files[:max_files],
                    api_key=api_key,
                    model_name=model_name,
                    temperature=temperature,
                )

            st.subheader("📂 File-by-file diffs")
            for result in refactor_results:
                rel = result["path"].relative_to(extracted_dir)
                st.markdown(f"### `{rel}`")

                if result["new_content"] is None:
                    st.text("No changes suggested or an error occurred.")
                    continue

                diff_text = generate_diff(
                    old_text=result["old_content"],
                    new_text=result["new_content"],
                    filename=str(rel),
                )
                st.code(diff_text, language="diff")

            # Create download zip
            with st.spinner("Creating refactored zip archive..."):
                # Overwrite files on disk with new contents
                for result in refactor_results:
                    if result["new_content"] is None:
                        continue
                    result["path"].write_text(result["new_content"], encoding="utf-8")

                zip_bytes = make_zip_from_dir(extracted_dir)

            st.download_button(
                label="⬇️ Download refactored codebase (.zip)",
                data=zip_bytes,
                file_name="refactored_codebase.zip",
                mime="application/zip",
            )


if __name__ == "__main__":
    main()
