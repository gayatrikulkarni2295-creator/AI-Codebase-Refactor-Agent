# 🧠 AI Codebase Refactor Agent (Streamlit + Gemini)

An AI agent that **analyzes**, **refactors**, and **documents** your codebase using **Google's Gemini** models and simple Python tools.

Upload a `.zip` of your project, provide your **Gemini API key**, and the app will:

- Scan your codebase
- Generate a high-level **refactor & quality report**
- Optionally **rewrite files** with cleaner structure, better naming, and docstrings
- Show **diffs** for each file
- Let you **download a refactored codebase** as a new `.zip`

---

## 🛠 Tech Stack

- **Frontend / UI**: [Streamlit](https://streamlit.io/)
- **LLM / Agent Brain**: [Google Generative AI (Gemini)](https://ai.google.dev/)
- **Language**: Python (simple standard library tools)
- No database, no complex backend – just a clean, hackathon-friendly setup.

---

## 📁 Project Structure

```text
ai_codebase_refactor_agent/
├── app.py                     # Streamlit UI entry point
├── refactor_agent/
│   ├── __init__.py
│   ├── agent.py               # Gemini integration + agent logic
│   └── code_utils.py          # File handling + diff utilities
├── requirements.txt
└── README.md
```

---

## 🚀 Getting Started

### 1. Clone or unzip this project

```bash
git clone <your-repo-url> ai-codebase-refactor-agent
cd ai-codebase-refactor-agent
```

Or, if you received this as a `.zip`, just extract it and open a terminal in the extracted folder.

---

### 2. Create a virtual environment (optional but recommended)

```bash
python -m venv .venv
source .venv/bin/activate   # On Windows: .venv\Scripts\activate
```

---

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

---

### 4. Get a Gemini API key

1. Go to the Google AI Studio site.
2. Create / log in to your Google account.
3. Create an API key for the **Gemini** models.
4. Copy the key.

---

### 5. Run the app

```bash
streamlit run app.py
```

Streamlit will show you a local URL (like `http://localhost:8501`). Open that in your browser.

---

## 🧩 How to Use

1. **Enter your Gemini API key** in the sidebar.
2. **Optionally adjust settings**:
   - Model name (default: `gemini-1.5-flash`)
   - Temperature
   - Max files to process
   - Mode: `Analyze only` or `Refactor & show diff`
3. **Upload your codebase as a `.zip`** file.
4. Click:
   - `🔍 Analyze codebase` to get a refactor plan + quality report; or
   - `🛠️ Refactor and show diffs` to let the agent rewrite files and show diffs.
5. If you refactored, download the new codebase with the **Download refactored codebase** button.

---

## 🧠 Agent Design

- The **analysis** step:
  - Lists files and includes truncated snippets.
  - Sends a compact description to Gemini with an architect-style prompt.
  - Gemini returns a structured report with refactor suggestions.

- The **refactor** step:
  - For each selected file:
    - Sends the full file + refactor instructions to Gemini.
    - Receives a fully rewritten version of the file.
  - Generates unified diffs for before/after.
  - Optionally writes the new files to disk and zips them for download.

This is intentionally built with **simple Python concepts** so you can:
- Read and understand the flow.
- Extend the agent’s tools (e.g., add tests, documentation, type checking).
- Customize prompts, add language filters, or integrate git directly.

---

## 🧪 Ideas for Improvement (Hackathon Extensions)

To make this project even more “winner-level”, you can add:

- **Test generator**: Agent writes or updates unit tests.
- **Quality score**: Before/after scoring using a simple rubric or LLM.
- **Tech stack detection**: Tailor suggestions for Django, React, etc.
- **GitHub integration**: Clone repos by URL, push refactor branch, create PR.
- **Safety checks**: Ask for confirmation before overwriting files.

---

## ⚠️ Notes

- Be careful when running refactors on production code. Always keep a backup or use git.
- LLM output may occasionally introduce bugs. Treat this as an assistant, not a compiler.

---

## 📜 License

You can use, modify, and extend this project freely for learning, hackathons, or internal tools. Add your preferred license (MIT, Apache-2.0, etc.) if you publish it.
